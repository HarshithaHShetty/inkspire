const axios = require("axios");

const getuserdetails = async (req, res, next) => {
  const userid = req.body.id; // Assuming the user ID is passed in the request body

  if (!userid) {
    return res.status(400).json({ message: "User ID is required" });
  }

  try {
    // Make a request to the external microservice to get user details

    const response = await axios.get(`http://localhost:3500/users/${userid}`, {
      headers: {
        Authorization: `Bearer ${req.headers.authorization.split(" ")[1]}`,
      },
    });

    // Check if the response has user data
    if (!response.data.username) {
      return res.status(404).json({ message: "No user found" });
    } else {
      req.user = response.data;
      next(); // Pass control to the next middleware (getCreatorSeries)
    }
  } catch (error) {
    console.error("Error fetching user details:", error.message);
    return res
      .status(500)
      .json({ error: "Failed to fetch user details from the other service" });
  }
};

module.exports = getuserdetails;
