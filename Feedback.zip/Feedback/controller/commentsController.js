
const Comment = require("../model/comments");
//getcomments
// // Controller to get comments based on episode ID
// //route /comment/:episodeId
const getComments = async (req, res) => {
  const { episodeId } = req.params; // Extracting episode ID from URL parameters

  try {
    // Find the feedback for the given episode ID
    const feedback = await Comment.findOne({ episode_id: episodeId });

    if (!feedback) {
      return res
        .status(404)
        .json({ message: "No comments found for this episode" });
    }

    // Return the comments associated with the episode
    res.status(200).json(feedback.epicomments);
  } catch (error) {
    console.error("Error fetching comments:", error);
    res.status(500).json({ message: "Error fetching comments", error });
  }
};
// Add comments
// Route: /comment/addcomment
const addComment = async (req, res) => {
  const { episode_id, creator_id, post_id, userId, comment } = req.body;

  try {
    // Create query based on whether the comment is for an episode or a post
    let feedback = await Comment.findOne({
      $or: [
        { episode_id, post_id: null }, // episode comment
        { post_id, creator_id } // post comment
      ]
    });

    if (feedback) {
      // If feedback exists, add the new comment
      feedback.epicomments.push({ userId, comment });
      await feedback.save();
    } else {
      // If no feedback exists, create a new feedback document
      feedback = new Comment({
        episode_id: episode_id || null,
        creator_id: creator_id || null,
        post_id: post_id || null,
        epicomments: [{ userId, comment }],
      });
      await feedback.save();
    }

    res.status(200).json({ message: "Comment added successfully", feedback });
  } catch (error) {
    console.error("Error adding comment:", error);
    res.status(500).json({ message: "Failed to add comment", error });
  }
};

// Add reply
// Route: /comment/addreply
const addReply = async (req, res) => {
  const { episode_id, post_id, commentId, userId, reply } = req.body;

  try {
    // Find the comment document by episode_id or post_id
    const feedback = await Comment.findOne({
      $or: [
        { episode_id },
        { post_id }
      ]
    });

    if (!feedback) {
      return res.status(404).json({ message: "Episode or post not found" });
    }

    // Find the specific comment by _id within epicomments array
    const comment = feedback.epicomments.id(commentId);

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // Add the reply to the comment
    comment.replies.push({ userId, reply });

    // Save the updated feedback document
    await feedback.save();

    res.status(200).json({ message: "Reply added successfully", feedback });
  } catch (error) {
    console.error("Error adding reply:", error);
    res.status(500).json({ message: "Failed to add reply", error });
  }
};

// Delete comment
// Route: /comment/delete
const deleteComment = async (req, res) => {
  const { episodeId, postId, commentId } = req.body;

  try {
    // Find the feedback (which contains the epicomments array) for the episode or post
    const feedback = await Comment.findOne({
      $or: [
        { episode_id: episodeId },
        { post_id: postId }
      ]
    });

    if (!feedback) {
      return res.status(404).json({ message: "Episode or post not found" });
    }

    // Find the index of the comment you want to delete
    const commentIndex = feedback.epicomments.findIndex(
      (epicomment) => epicomment._id.toString() === commentId
    );

    if (commentIndex === -1) {
      return res.status(404).json({ message: "Comment not found" });
    }

    // Remove the comment along with its replies
    feedback.epicomments.splice(commentIndex, 1);

    // Save the updated document after deletion
    await feedback.save();

    res.status(200).json({ message: "Comment and its replies deleted successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Error deleting comment", error });
  }
};

// Edit comment
// Route: /comment/edit
const editComment = async (req, res) => {
  const { episodeId, postId, commentId, commentText } = req.body;
  try {
    const feedback = await Comment.findOne({
      $or: [
        { episode_id: episodeId },
        { post_id: postId }
      ]
    });

    if (!feedback) {
      return res.status(404).json({ message: "Episode or post not found" });
    }

    // Find and update the comment
    const comment = feedback.epicomments.id(commentId);
    if (!comment) {
      return res.status(404).json({ message: "Comment not found" });
    }

    comment.comment = commentText;
    await feedback.save();
    res.status(200).json({ message: "Comment updated successfully", comment });
  } catch (error) {
    res.status(500).json({ message: "Error updating comment", error });
  }
};

module.exports = {
  addComment,
  addReply,
  deleteComment,
  editComment,
  getComments,
};
