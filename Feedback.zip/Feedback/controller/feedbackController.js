const Feedback = require("../model/feedback");
const mongoose = require("mongoose");

// Like/Unlike a series
//route /feedback/like
const likeSeries = async (req, res) => {
  const { series_id, creator_id, post_id, userId } = req.body;

  try {
    let query = series_id ? { series_id } : { creator_id, post_id };
    let feedback = await Feedback.findOne(query);

    if (!feedback) {
      feedback = new Feedback(series_id ? { series_id } : { creator_id, post_id, likes: [] });
    }

    const liked = feedback.likes.some((like) => like.userId.equals(userId));
    if (liked) {
      feedback.likes = feedback.likes.filter((like) => !like.userId.equals(userId));
    } else {
      feedback.likes.push({ userId });
    }

    await feedback.save();
    res.status(200).json({ message: liked ? "Unliked" : "Liked", feedback });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};


//subscribe
//route /feedback/subscribe
const subscribeSeries = async (req, res) => {

const { userId, series_id, creator_id } = req.body;

try {
  // Determine which query to use based on the presence of series_id or creator_id
  const query = series_id ? { series_id } : creator_id ? { creator_id, post_id: null } : null;

  if (!query) {
    return res.status(400).json({ message: "Missing series_id or creator_id" });
  }

  // Check if feedback exists for the series or creator
  let feedback = await Feedback.findOne(query);

  if (!feedback) {
    // Create new feedback entry if it doesn't exist
    feedback = new Feedback({
      ...query,
      subscribers: [],
    });
  }

  // Check if the user is already subscribed
  const subscribed = feedback.subscribers.some((subscriber) =>
    subscriber.userId.equals(userId)
  );

  if (subscribed) {
    // User already subscribed, so unsubscribe (remove from subscribers array)
    feedback.subscribers = feedback.subscribers.filter(
      (subscriber) => !subscriber.userId.equals(userId)
    );
  } else {
    // User has not subscribed yet, so subscribe (add userId to subscribers array)
    feedback.subscribers.push({ userId });
  }

  // Save the updated feedback
  await feedback.save();

  // Send response
  res.status(200).json({
    message: series_id
      ? subscribed
        ? "Unsubscribed from the series"
        : "Subscribed to the series"
      : subscribed
      ? "Unsubscribed from the creator"
      : "Subscribed to the creator",
    feedback,
  });
} catch (error) {
  console.error(error);
  res.status(500).json({ message: "Server error" });
}
};



//updateviews
//route /feedback/views
const updateViews = async (req, res) => {
  const { series_id } = req.body;

  if (!series_id) {
    return res.status(400).json({ message: "update views only for series" });
  }
  try {
    // Check if feedback exists for the series
    let feedback = await Feedback.findOne({ series_id });

    if (!feedback) {
      // Create new feedback entry if it doesn't exist
      feedback = new Feedback({ series_id, views: 0 });
    }

    // Increment the view count
    feedback.views += 1;

    // Save the updated feedback
    await feedback.save();

    // Send response
    res.status(200).json({
      message: "View count updated",
      feedback,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

//rating
//route /feedback/rate
const rateSeries = async (req, res) => {
  const { series_id, userId, rating } = req.body;

  if (!series_id) {
    return res.status(400).json({ message: "Ratings are only allowed for series." });
  }
  try {
    // Validate rating
    if (rating < 1 || rating > 5) {
      return res
        .status(400)
        .json({ message: "Rating should be between 1 and 5" });
    }

    // Check if feedback exists for the series
    let feedback = await Feedback.findOne({ series_id });

    if (!feedback) {
      // Create new feedback entry if it doesn't exist
      feedback = new Feedback({ series_id, ratings: [] });
    }

    // Check if user has already rated the series
    const existingRatingIndex = feedback.ratings.findIndex((r) =>
      r.userId.equals(userId)
    );
    if (existingRatingIndex !== -1) {
      // Update the user's existing rating
      feedback.ratings[existingRatingIndex].rating = rating;
    } else {
      // User hasn't rated yet, so add the rating
      feedback.ratings.push({ userId, rating });
    }

    // Save the updated feedback
    await feedback.save();

    // Send response
    res.status(200).json({
      message: "Rating updated",
      feedback,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

//getrequests

//getviews
//route /feedback/getview/:series_id
const getViews = async (req, res) => {
  const { series_id } = req.params;

  try {
    // Find feedback document for the given series_id
    const feedback = await Feedback.findOne({ series_id });

    if (!feedback) {
      return res
        .status(404)
        .json({ message: "No feedback found for this series" });
    }

    // Send response with view count
    res.status(200).json({
      message: "View count fetched successfully",
      views: feedback.views,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

//getrating of series
//route /feedback/getrating/:series_id
const getRating = async (req, res) => {
  const { series_id } = req.params;

  try {
    // Find feedback document for the given series_id
    const feedback = await Feedback.findOne({ series_id });

    if (!feedback) {
      return res
        .status(404)
        .json({ message: "No feedback found for this series" });
    }

    // Calculate the average rating
    const ratings = feedback.ratings;
    const totalRatings = ratings.length;

    if (totalRatings === 0) {
      return res.status(200).json({
        message: "No ratings found for this series",
        averageRating: 0, // Return 0 if no ratings
      });
    }

    const averageRating =
      ratings.reduce((acc, r) => acc + r.rating, 0) / totalRatings;

    // Send response with the average rating
    res.status(200).json({
      message: "Average rating fetched successfully",
      averageRating: averageRating.toFixed(2), // Returning average rating with 2 decimal points
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  likeSeries,
  subscribeSeries,
  updateViews,
  rateSeries,
  getViews,
  getRating,
};
