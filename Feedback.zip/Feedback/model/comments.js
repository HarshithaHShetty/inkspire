const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema(
  {
    episode_id: {
      type: mongoose.Schema.Types.ObjectId,

   
    },
    creator_id: {
      type: mongoose.Schema.Types.ObjectId,
  
    },
    post_id: {
      type: mongoose.Schema.Types.ObjectId,
      required: false, // Required only for comments on specific posts
    },
    epicomments: [
      {
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          required: true,
        },
        comment: {
          type: String,
          required: true,
        },
        replies: [
          {
            userId: {
              type: mongoose.Schema.Types.ObjectId,
              ref: "User",
              required: true,
            },
            reply: {
              type: String,
              required: true,
            },
            createdAt: {
              type: Date,
              default: Date.now,
            },
          },
        ],
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
  },
  {
    timestamps: true, // Automatically add createdAt and updatedAt fields
  }
);

module.exports = mongoose.model("Comment", commentSchema);
