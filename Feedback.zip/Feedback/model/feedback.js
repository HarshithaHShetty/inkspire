const mongoose = require("mongoose");

const feedbackSchema = new mongoose.Schema(
  {
    series_id: {
      type: mongoose.Schema.Types.ObjectId,
    
    },
    creator_id: {
      type: mongoose.Schema.Types.ObjectId,
   
    },
    post_id: {
      type: mongoose.Schema.Types.ObjectId,
    },
    likes: [
      {
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          required: true,
        },
      },
    ],
    subscribers: [
      {
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          required: true,
          ref: "User",
        },
      },
    ],
    views: {
      type: Number,
      default: 0,
    },
    ratings: [
      {
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User", // Assuming User is in another microservice
          required: true,
        },
        rating: {
          type: Number,
          min: 1,
          max: 5,
          required: true,
        },
      },
    ],
  },
  {
    timestamps: true, // Automatically add createdAt and updatedAt fields
  }
);

module.exports = mongoose.model("Feedback", feedbackSchema);
