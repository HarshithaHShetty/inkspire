const allowedOrigins=["http://localhost:3502"]

module.exports = allowedOrigins