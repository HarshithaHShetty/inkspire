const express = require("express");
const {
  likeSeries,
  subscribeSeries,
  updateViews,
  rateSeries,
  getViews,
  getRating,
} = require("../controller/feedbackController"); // Adjust the path according to your project structure

const router = express.Router();

router.post("/like", likeSeries);
router.post("/subscribe", subscribeSeries);
router.post("/views", updateViews);
router.post("/rate", rateSeries);

router.get("/getview/:series_id", getViews);
router.get("/getrating/:series_id", getRating);

module.exports = router;
