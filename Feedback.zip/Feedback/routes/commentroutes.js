const express = require("express");
const router = express.Router();
const commentsController = require("../controller/commentsController");

router.post("/addComment", commentsController.addComment);
router.post("/addReply", commentsController.addReply);

router.delete("/delete", commentsController.deleteComment);

router.put("/edit", commentsController.editComment);

router.get("/:episodeId", commentsController.getComments);

module.exports = router;

// router.put("edit/:episodeId/:commentId", commentsController.editComment);
