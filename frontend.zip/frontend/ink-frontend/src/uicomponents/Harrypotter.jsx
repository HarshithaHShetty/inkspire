import React from 'react'
import './Harrypotter.css'
function Harrypotter() {
  return (
    <div className= 'harry'>
    <div className= 'hair'> 
        <div className= 'hair-toppest'></div>
        <div className= 'hair-toppest-part-two'></div>
        <div className= 'hair-toppest-part-three'></div>
        <div className= 'hair-left'></div>
        <div className= 'hair-left-part-two'></div>
        <div className= 'hair-right'></div>
        <div className= 'hair-right-part-two'></div>
        <div className= 'hair-right-hide'></div>
        <div className= 'hair-top'></div>
        <div className= 'hair-top-part-two'></div>
        <div className= 'hair-bottom'></div>
        <div className= 'hair-left-hide'></div>
        <div className= 'hair-left-hide-part-two'></div>
        <div className= 'hair-bottom-hide'></div>
        <div className= 'hair-bottom-hide-part-two'></div>
    </div> 
    <div className= 'ear ear-left'></div>
    <div className= 'ear ear-right'></div>
    <div className= 'head'></div>
    <div className= 'scar'></div>
    <div className= 'glasses-left'></div>
    <div className= 'glasses-right'></div>
    <div className= 'glasses-bridge'></div>
    <div className= 'glasses-hand-left'></div>
    <div className= 'glasses-hand-right'></div>
    <div className= 'eyebrow'></div>
    <div className= 'eye-left'></div>
    <div className= 'eye-right'></div>
    <div className= 'eye-glass-left'></div>
    <div className= 'eye-glass-right'></div>
    <div className= 'nose'></div>
    <div className= 'mouth'></div>
    <div className= 'cheek-left'></div>
    <div className= 'cheek-right'></div>
    <div className= 'body'>
        <div className= 'tie'></div>
        <div className= 'tie-bottom'></div>
        <div className= 'shirt'></div>
        <div className= 'collar'></div>
        <div className= 'gown-collar'></div>
        <div className= 'gown'></div>
        <div className= 'gown gown-part-two'></div>
        <div className= 'foot foot-left'></div>
        <div className= 'foot foot-right'></div>
        <div className= 'sleeve-left'></div>
        <div className= 'paw-left'></div>
        <div className= 'sleeve-right'></div>
        <div className= 'sleeve-right-hide'></div>
        <div className= 'sleeve-right-hide-part-two'></div>
        <div className= 'paw-right'></div>
        <div className= 'wand'></div>
        <div className= 'badge'></div>
    </div>
</div>

  )
}

export default Harrypotter