import React from "react";
import "./SeriesCard.css";

function SeriesCard() {
  return (
    <div className="group perspective group-hover:rotate-y-180">
      <div className="relative w-56 h-80 transform-style-preserve-3d transition-transform duration-700 group-hover:[transform:rotateY(180deg)]">
        {/* Front Side */}
        <div className="absolute w-full h-full backface-hidden bg-black text-white rounded-lg overflow-hidden shadow-lg">
          <div className="p-2">
            <img
              src="images/skyscraper2.jpg"
              alt="Series Cover"
              className="w-full h-64 rounded-lg object-cover"
            />
            <h3 className="mt-2 text-center font-semibold">Series Title</h3>
          </div>
        </div>

        {/* Back Side */}
        <div className="absolute w-full h-full backface-hidden bg-red-800 text-white rounded-lg rotate-y-180 p-4 flex flex-col justify-center shadow-lg">
          <h3 className="text-lg font-bold">Series Info</h3>
          <p className="mt-2 text-sm">This is a synopsis of the series.</p>
          <p className="mt-2 text-sm font-semibold">Genre: Action</p>
          <p className="mt-1 text-sm italic">"An epic journey awaits."</p>
        </div>
      </div>
    </div>

  );
}

export default SeriesCard;
