import React, { useState } from 'react';
import Logo from './Logo';
import { logout} from "../features/Auth/authSlice";
import { useDispatch } from 'react-redux';
import { BookMarked, Heart, PenBox, CircleFadingPlus } from "lucide-react";

const UserButton = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const dispatch = useDispatch();

  const toggleModal = () => {
    setIsModalOpen((prev) => !prev);
  };
  const handleLogout = () => {
    dispatch(logout()); // Dispatch the logout action
    alert('You have been logged out.'); // Optional: Show a feedback message
  };
  return (
    <div className="relative">
      {/* User Profile Button */}
      <button
        onClick={toggleModal}
        className="bg-gray-800 rounded-full w-10 h-10 flex items-center justify-center"
      >
        <i className="text-purple-500 text-xl fa fa-user"></i>
      </button>

      {/* Modal */}
      {isModalOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-gray-900 border border-gray-700 rounded-lg shadow-lg z-50">
          {/* User Info */}
          <div className="flex items-center px-4 py-3 border-b border-gray-700">
            <div className="bg-purple-500 rounded-full w-8 h-8 flex items-center justify-center text-white">
              <i className="fa fa-user"></i>
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-300">Creator</p>
            </div>
          </div>

          {/* Menu Items */}
          <div className="py-2">
            <button
              className="w-full text-left px-4 py-2 text-sm hover:bg-gray-800 flex items-center space-x-2 text-white"
              onClick={() => alert('My Drafts clicked')}
            >
              <i className="fa fa-plus text-gray-400"></i>
              <span>My Drafts</span>
            </button>
            <button
              className="w-full text-left px-4 py-2 text-sm hover:bg-gray-800 flex items-center space-x-2 text-white "
              onClick={() => alert('Manage Account clicked')}
            >
              <i className="fa fa-cog text-gray-400"></i>
              <span>Manage account</span>
            </button>
            <button
              className="w-full text-left px-4 py-2 text-sm hover:bg-gray-800 flex items-center space-x-2 text-white"
              onClick={handleLogout}
            >
              <i className="fa fa-sign-out-alt text-gray-400"></i>
              <span>Sign out</span>
            </button>
          </div>

          {/* Footer */}
          <div className="px-4 py-2 text-xs text-gray-400 border-t border-gray-700">
          <Logo/>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserButton;
