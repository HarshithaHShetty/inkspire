import React from 'react';
import './Logo.scss';

const Logo = ({ fontSize }) => {
  return (
    <h1 className="brand-name" style={{ fontSize }}>
      <span className="i-letter">i</span>
      <span className="nks">NK</span>
      <span className="s-letter">S</span>
      <span className="pire">PIRE</span>
    </h1>
  );
};

export default Logo;
