import React from 'react';

function Epcard() {
  return (
    <div className="flex items-start w-11/12 p-5 mb-5 bg-gradient-to-tr from-black to-red-700 rounded-xl transition-transform duration-300 ease-in-out transform hover:scale-105 hover:shadow-lg">
      <div className="flex-shrink-0 mr-5 h-34">
        <img
          src="https://via.placeholder.com/130"  // Placeholder image URL
          alt="Episode Thumbnail"
          className="w-32 h-32 object-cover rounded-lg border-2 border-red-600 transition-transform duration-300 ease-in-out hover:scale-110"
        />
      </div>
      <div className="flex-grow text-white">
        <h2 className="text-xl font-bold mb-2">Episode 1: Sample Episode Title</h2>
        <p className="text-lg text-gray-300 leading-relaxed">This is a description of the episode. It provides a brief summary of the content and storyline.</p>
      </div>

      <button className="bg-gradient-to-tr from-red-700 to-black text-white px-6 py-2 text-lg rounded-md transition-colors duration-300 ease-in-out hover:bg-red-600">
        Edit Draft
      </button>
    </div>
  );
}

export default Epcard;
