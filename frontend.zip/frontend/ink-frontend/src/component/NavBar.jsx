import React from "react";
import Logo from "../uicomponents/Logo";
import { BookMarked, Heart, PenBox, CircleFadingPlus } from "lucide-react";
import { Link } from "react-router-dom";
import UserButton from "../uicomponents/Userbutton";

function Navbar() {



  return (
    <div className="navbar fixed top-0 left-0 right-0 z-50 flex justify-between items-center bg-opacity-80 backdrop-blur-lg bg-black px-6 py-3">
      {/* Left Section */}
      <div className="navbar-left flex items-center">
        {/* <Link to="/role" className="flex items-center text-white no-underline">
          <Logo />
        </Link> */}
        <Logo/>
      </div>

      {/* Right Section */}
   
        <div className="navbar-right flex items-center space-x-4">
          {/* {user?.unsafeMetadata?.role === "creator" && pathname === "/creatordashboard" && (
            <Link to="/new-series">
              <button className="new-button bg-gradient-to-r from-red-600 to-black text-white rounded-md px-4 py-2 text-sm font-medium shadow-lg hover:from-black hover:to-red-600 transform hover:scale-105 active:scale-95 transition-all">
                <PenBox size={20} className="mr-2 inline-block" />
                New Series
              </button>
            </Link>
          )} */}

          {/* <div>
            <UserButton
              appearance={{
                elements: {
                  userButtonAvatarBox: "w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center",
                  userButtonAvatarImage: "rounded-full",
                  modalBox: "bg-gray-900 text-white border border-gray-800 rounded-lg shadow-lg",
                  menuItem: "hover:bg-gray-800 px-4 py-2 flex items-center text-sm",
                  menuItemIcon: "text-gray-400 mr-3",
                },
              }}
            >
           }
              {user?.unsafeMetadata?.role === "reader" ? (
                <>
                  <UserButton.Link
                    label="Favourites"
                    labelIcon={<Heart size={15} />}
                    href="/favourites"
                  />
                  <UserButton.Link
                    label="My reads"
                    labelIcon={<BookMarked size={15} />}
                    href="/my-reads"
                  />
                  <UserButton.Action label="Manage Account" />
                </>
              ) : (
                <>
                  <UserButton.Link
                    label="My Drafts"
                    labelIcon={<CircleFadingPlus size={15} />}
                    href="/my-drafts"
                  />
                  <UserButton.Action label="Manage Account" />
                </>
              )}
            </UserButton>
          </div> */}
          <UserButton/>
        </div>
  
    </div>
  );
}

export default Navbar;
