import React from "react";
import "./Landingpage.css";
import Cat from "./cat";

// import { Link } from "react-router-dom";
import Logo from "../uicomponents/Logo";

function LandingPage() {
  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      {/* Curtain effect */}
      <div className="flex w-full h-full overflow-hidden">
        <div
          className="w-1/2 h-full bg-cover bg-left curtain-left animate-slide-left"
          style={{ backgroundImage: "url('/images/curtains-left.jpg')" }}
        ></div>
        <div
          className="w-1/2 h-full bg-cover bg-right curtain-right animate-slide-right"
          style={{ backgroundImage: "url('/images/curtains-right.jpg')" }}
        ></div>
      </div>

      <Cat />
      <div className="getstarted absolute w-[700px] overflow-hidden z-2 top-[25%] right-[10px] bottom-[30%]">
        <p className="para absolute text-white  opacity-0 text-3xl right-[30px] ">
          今日は素晴らしい日です。新しいプロジェクトが始まり、ワクワクしています。未来のテクノロジーに期待しています。
          私たちの未来は、私たちが今日行う選択に大きく依存しています。技術の進歩により、今では多くの問題が解決可能になりつつあります。
          し、進化には常にリスクも伴います。私たちは、新しいアイデアに対して開かれた心を持ちつつも、慎重にその影響を評価し、持続可能法で進化していかなければなりません。社会の一員として、私たちの行動が他の人々に与える影響を考慮することが重要です。人工知能や自動化が進む中で、人間らしさをどのように保つかという問いも浮かび上がっています。私たちは、技術を支配するのではなく、技術と共に生きていく方法を見つけるべきです。未来の世界で求められるのは、創造性、共感、そして倫理的な判断力です。今後も挑戦的な課題が私たちを待ち受けていますが、それに立ち向かうためには団結が必要です。私たちの未来をより良いものにするために、一人一人ができることを考え、行動する時です。技術がどれだけ進化しようとも、人間の心と知恵が最も重要であることを忘れずに。
          私たちの未来は、私たちが今日行う選択に大きく依存しています。技術の進歩により、今では多くの問題が解決可能になりつつあります。しかし、進化には常にリスクも伴います。私たちは、新しいアイデアに対して開かれた心を持ちつつも、慎重にその影響を評価し、持続可能な方法で進化していかなければなりません。社会の一員として、私たちの行動が他の人々に与える影響を考慮することが重要です。人工知能や自動化が進む中で、人間らしさをどのように保つかという問いも浮かび上がっています。私たちは、技術を支配するのではなく、技術と共に生きていく方法を見つけるべきです。未来の世界で求められるのは、創造性、共感、そして倫理的な判断力です。今後も挑戦的な課題が私たちを待ち受けていますが、それに立ち向かうためには団結が必要です。私たちの未来をより良いものにするために、一人一人ができることを考え、行動する時です。技術がどれだけ進化しようとも、人間の心と知恵が最も重要であることを忘れずに。
        </p>
        <span className="logo absolute top-0 right-[40%] opacity-0">
          <Logo fontSize="5rem" />
        </span>
      </div>
      <div className="log flex absolute top-[55%] right-[42%] no-underline ">
  <a href="#" className="no-underline">
    <h1 className="text-gray-400 font-mono text-4xl font-semibold overflow-hidden whitespace-nowrap tracking-wide animation-typing">SignIn</h1>
  </a>
</div>

<div className="reg flex absolute top-[55%] right-[7%]  no-underline z-[700]">
  <a href="#" className="no-underline">
    <h1 className="text-gray-400 font-mono text-4xl font-semibold overflow-hidden whitespace-nowrap tracking-wide animation-typing">SignUp</h1>
  </a>
</div>

    </div>
  );
}

export default LandingPage;
