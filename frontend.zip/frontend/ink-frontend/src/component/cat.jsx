import React from "react";
import "./cat.css";
function Cat() {
  return (
    //     <>
    // <div className="cat relative w-32 h-32 mb-10 animate-slide-in">
    // {/* Cat face and features */}
    // <div className="absolute h-[150px] w-[170px] sm:h-[170px] sm:w-[192px] md:h-[200px] md:w-[226px] lg:h-[220px] lg:w-[248px]">

    // <div className="absolute ear ear--left bg-white h-[60%] w-[25%] -top-[30%] left-[-7%]"></div>
    // <div className="absolute ear ear--right bg-white h-[60%] w-[25%] -top-[30%] right-[-7%]"></div>

    // <div className="face relative bg-black rounded-full">
    //   <div className="eye eye--left absolute bg-white rounded-full">
    //     <div className="eye-pupil bg-black rounded-full relative"></div>
    //   </div>
    //   <div className="eye eye--right absolute bg-white rounded-full">
    //     <div className="eye-pupil bg-black rounded-full relative"></div>
    //   </div>
    //   <div className="muzzle bg-white absolute rounded-full"></div>
    // </div>

    // </div>
    // </div>
    // </>
    <>
      <div className="absolute left-[43%] top-[45%] animate-slide-in">
        <div className="absolute h-[170px] w-[192px]">
          <div className="ear ear--left"></div>
          <div className="ear ear--right"></div>
          <div className="face bg-black">
            <div className="eye eye--left">
              <div className="eye-pupil"></div>
            </div>
            <div className="eye eye--right">
              <div className="eye-pupil"></div>
            </div>
            <div className="muzzle"></div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Cat;
