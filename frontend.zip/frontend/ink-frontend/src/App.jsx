import React from "react";
import { Provider } from "react-redux";
import store from "./app/store";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./app/api/ProtectedRoute";
import LandingPage from "./component/Landingpage";
import Register from "./features/register";
import FloatingPieces from "./features/test/FloatingPieces";
import Login from "./features/Auth/Login";
import Otp from "./features/Auth/Otp";
import Harrypotter from "./uicomponents/HarryPotter";
import Readerdashboard from "./features/Reader/ReaderDashboard";
import SeriesCard from "./uicomponents/SeriesCard";
import Epcard from "./uicomponents/EpCard";
import UserButton from "./uicomponents/Userbutton";
import NavBar from "./component/NavBar";
import Dummy from "./features/Reader/Dummy";

function App() {
  return (
    // <LandingPage/>
    //<Register/>
    //  <FloatingPieces/>
    //  <Login/>
    //<Readerdashboard/>
    //<SeriesCard/>
    //<Epcard/>
    //<UserButton/>
    //<NavBar/>
    <Router>
      <Routes>
        <Route path="/dummy" element={<Dummy />} />
        <Route path="/register" element={<FloatingPieces/>} />
          <Route path="/login" element={<Login/>} />
          
      </Routes>
    </Router>
  );
}

export default App;
{
  /* <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/register" element={<FloatingPieces/>} />
          <Route path="/login" element={<Login/>} />
          
          <Route
            path="/landing"
            element={
              <ProtectedRoute>
                <LandingPage/>
              </ProtectedRoute>
            }
          />
        </Routes>
      </Router>
    </Provider> */
}
