import React, { useState } from 'react';
import "./FloatingPieces.css"
import Logo from '../../uicomponents/Logo'
import { useNavigate } from 'react-router-dom';
import { useRegisterMutation } from '../Auth/authAPI';

const FloatingPieces = () => {
  const [role, setRole] = useState('');
  const [formData, setFormData] = useState({ username: '', email: '', password: '' });
  const [register, { isLoading, error }] = useRegisterMutation();
  const navigate = useNavigate();


  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formDataWithRole = { ...formData, role };
    
      await register(formDataWithRole).unwrap();
      alert('Registration successful! Proceed to login.');
      navigate('/login');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="relative h-screen w-full bg-grid flex items-center justify-center overflow-hidden">
    

      {/* Floating Pieces */}
      {/* Floating 3D-Like Pills */}
      <div className="w-full max-w-xs m-auto bg-transparent rounded p-5 float-left">   
      <header>
        <Logo fontSize="2rem"/>
      </header>  
    
      <form onSubmit={handleSubmit}>
        <div>
          <label className="block mb-2 text-red-600" htmlFor="username">Username</label>
          <input className="w-full p-2 mb-6 text-red-700 border-b-2 border-indigo-500 outline-none focus:bg-gray-300" type="text" name="username" onChange={(e) => setFormData({ ...formData, username: e.target.value })}
          required/>
        </div>
        <div>
          <label className="block mb-2 text-red-600" htmlFor="email">Email</label>
          <input className="w-full p-2 mb-6 text-red-700 border-b-2 border-indigo-500 outline-none focus:bg-gray-300" type="email" name="email" onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          required/>
        </div>
        <div>
          <label className="block mb-2 text-red-600" htmlFor="password">Password</label>
          <input className="w-full p-2 mb-6 text-red-700 border-b-2 border-indigo-500 outline-none focus:bg-gray-300" type="password" name="password" onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          required/>
        </div>
         {/* Role Selection */}
         <div className="mb-6">
              <label className="block mb-2 text-indigo-500">Select Role</label>
              <div className="flex items-center space-x-4">
                <label className="flex items-center text-white">
                  <input
                    type="radio"
                    name="role"
                    value="creator"
                    checked={role === 'creator'}
                    onChange={handleRoleChange}
                    className="mr-2"
                  />
                  Creator
                </label>
                <label className="flex items-center text-white">
                  <input
                    type="radio"
                    name="role"
                    value="reader"
                    checked={role === 'reader'}
                    onChange={handleRoleChange}
                    className="mr-2"
                  />
                  Reader
                </label>
              </div>
            </div>

        <div>          
          <input className="w-full bg-indigo-700 hover:bg-pink-700 text-white font-bold py-2 px-4 mb-6 rounded" type="submit"/>
        </div>  
             
      </form>  
      <footer>
        <a className="text-indigo-700 hover:text-pink-700 text-sm " href="#">Already a user? Login</a>
      </footer>   
    </div>
    
      
      <div className="absolute bottom-1/4 left-10 piece overflow-hidden bg-fuchsia-300 grp1"></div>
      <div className="absolute bottom-1/3 right-1/4 piece bg-gray-500 grp3"></div>
      <div className="absolute top-1/4 left-12 piece bg-gray-500  grp1"></div>
      <div className="absolute top-1/4 left-12   grp2 piece bg-gray-500 " ></div>

      <div className="absolute bottom-5 left-1/6   grp2 piece bg-yellow-300"></div>
      <div className="absolute top-20 left-1/4  grp1 piece bg-rose-400"></div>
      <div className="absolute top-1/4 left-1/5  grp2 piece bg-teal-200"></div>

      <div className="absolute top-10 right-20  grp3 piece bg-blue-300"></div>
      <div className="absolute bottom-1/4 left-1/3 grp2 piece bg-fuchsia-300"></div>
      <div className="absolute top-10 left-1/8 piece grp3 bg-gray-500"></div>

      <div className="absolute top-1/5 right-10  grp1 piece bg-gray-500"></div>
      <div className="absolute top-28 left-2/3 grp2 piece bg-yellow-300"></div>
      <div className="absolute bottom-16 left-1/3  grp2 piece bg-rose-400"></div>

      <div className="absolute top-28 left-10  grp3 piece bg-blue-300"></div>
      <div className="absolute bottom-1/2 left-1/3 grp1 piece bg-fuchsia-300"></div>
      <div className="absolute top-1/3 right-1/4 piece grp3 bg-gray-500"></div>

      <div className="absolute top-28 left-10  grp3 piece bg-blue-300"></div>
      <div className="absolute bottom-1/2 left-1/3 grp1 piece bg-fuchsia-300"></div>
      <div className="absolute top-1/3 right-1/4 piece grp3 bg-gray-500"></div>

      <div className="absolute bottom-20 right-1/3  grp3 piece bg-teal-200"></div>
    </div>
  );
};

export default FloatingPieces;