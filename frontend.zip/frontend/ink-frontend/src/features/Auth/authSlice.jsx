// import { createSlice } from '@reduxjs/toolkit'
 
// const authSlice = createSlice({
//     name: 'auth',
//     initialState: { token: null },
//     reducers: {
//         setCredentials: (state, action) => {
//             const { accessToken } = action.payload
//             state.token = accessToken
//         },
//         logOut: (state, action) => {
//             state.token = null
//         },
//     }
// })
 
// export const { setCredentials, logOut } = authSlice.actions
 
// export default authSlice.reducer
 
// export const selectCurrentToken = (state) => state.auth.token
import { createSlice } from '@reduxjs/toolkit';

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    token: null,
    user: null,
    otpVerified: false,
  },
  reducers: {
    setCredentials: (state, action) => {
      state.token = action.payload.token;
    },
    setError: (state, action) => {
        state.error = action.payload;
    },
    setUser: (state, action) => {
      state.user = action.payload;
    },
    setOtpVerified: (state, action) => {
      state.otpVerified = action.payload;
    },
    logout: (state) => {
      state.token = null;
      state.user = null;
      state.otpVerified = false;
    },
  },
});

export const { setCredentials, setUser, setOtpVerified, logout,setError} = authSlice.actions;
export default authSlice.reducer;
