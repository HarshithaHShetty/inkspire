
import React, { useRef, useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import Otp from './Otp'; // Import OTP component
import Logo from '../../uicomponents/Logo';
import './Login.css';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setUser, setError } from './authSlice';
import { useLoginMutation } from './authAPI';
import UserButton from '../../uicomponents/Userbutton';
// import usePersist from '../../hooks/usePersist';

function Login() {
  const userRef = useRef();
  const errRef = useRef();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  // const [persist, setPersist] = usePersist();

  const [showOtpModal, setShowOtpModal] = useState(false);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { errorMessage } = useSelector((state) => state.auth); // Select error state from Redux

  const [login, { isLoading }] = useLoginMutation();

  useEffect(() => {
    userRef.current.focus();
  }, []);

  useEffect(() => {
    if (errorMessage) {
      errRef.current.focus();
    }
  }, [errorMessage]);

  // const handleLoginClick = async (e) => {
  //   e.preventDefault();
  //   try {
  //     const userData = await login({ email, password }).unwrap();
  //     console.log('Login Response:', userData);
  //     dispatch(setUser(userData.user));
  //     console.log(userData,"1");  // Check the entire response
  //     console.log(userData.data,"2"); 
  //     setShowOtpModal(true); // Show OTP modal
  //   } catch (err) {
  //     const error = err?.data?.message || 'Login failed';
  //     dispatch(setError(error));
  //   }
  //   // If the user data is inside a `data` object

    
  // };
  const handleLoginClick = async (e) => {
    e.preventDefault();
    try {
      const userData = await login({ email, password }).unwrap();
      console.log('Login Response:', userData);
  
      // Adjust this based on the actual response structure
      const user = userData.user; // Assuming `user` is directly available
      const message = userData.message; // Assuming `message` is directly available
  
      if (user) {
        dispatch(setUser(user)); // Save user in Redux state
      }
      if (message) {
        console.log('Message:', message); // Log OTP message
      }
      console.log('Full Response:', userData);
      console.log('User:', userData.user || userData.data?.user);
      console.log('Message:', userData.message || userData.data?.message);
      
      setShowOtpModal(true); // Show OTP modal
    } catch (err) {
      const error = err?.data?.message || 'Login failed';
      dispatch(setError(error));
    }
  };
  

  const handleCloseModal = () => {
    setShowOtpModal(false); // Close OTP component
  };

  return (
    <>
      {/* Background with conditional blur when OTP modal is visible */}
      <div
        className={`relative h-screen w-full bg-[url('/images/skyscraper2.jpg')] bg-cover flex items-center justify-center overflow-hidden ${
          showOtpModal ? 'backdrop-blur-sm' : ''
        }`}
      >
        <div className="w-full max-w-xs m-auto bg-transparent rounded p-5 float-left">
          <header>
            <Logo fontSize="2rem" />
          </header>
          <form>
            {errorMessage && (
              <p
                ref={errRef}
                className="text-red-500 text-sm mb-4 text-center"
              >
                {errorMessage}
              </p>
            )}
            <div>
              <label className="block mb-2 text-red-600" htmlFor="email">
                Email
              </label>
              <input
                ref={userRef}
                className="w-full p-2 mb-6 text-red-700 border-b-2 outline-none focus:bg-gray-300"
                type="email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="block mb-2 text-red-600" htmlFor="password">
                Password
              </label>
              <input
                className="w-full p-2 mb-6 text-red-700 border-b-2 outline-none focus:bg-gray-300"
                type="password"
                name="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div>
              <button
                className="w-full bg-red-700 hover:bg-pink-700 text-white font-bold py-2 px-4 mb-6 rounded"
                onClick={handleLoginClick}
                disabled={isLoading}
              >
                {isLoading ? 'Logging in...' : 'Login'}
              </button>
            </div>
          </form>
        </div>
        <div className="absolute right-20 top-1/4 transform -translate-y-1/2">
          <img
            className="spiderman"
            src="https://i.ibb.co/XDFkXMx/spiderman-colgado.png"
            alt="Spiderman"
          />
        </div>
        <UserButton/>
      </div>

      {/* Render OTP Component using React Portal */}
      {showOtpModal &&
        createPortal(
          <Otp onClose={handleCloseModal} />, // Pass close function to OTP component
          document.body // Render OTP outside the current component hierarchy
        )}
    </>
  );
}

export default Login;
