
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import HarryPotter from '../../uicomponents/HarryPotter';
import { useDispatch } from 'react-redux';
import { useVerifyOtpMutation } from './authAPI';
import { setOtpVerified,setCredentials } from './authSlice';
import { useNavigate } from 'react-router-dom';
const Otp = ({ onClose }) => {
  const [otp, setOtp] = useState(Array(6).fill(''));
  const [verifyOtp, { isLoading, error }] = useVerifyOtpMutation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector((state) => state.auth.user);
  const email = user?.email;
  console.log(email); 
  const handleChange = (e, index) => {
    const value = e.target.value;
    if (/\d/.test(value) || value === '') {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Automatically focus next input
      if (value !== '' && index < 5) {
        document.getElementById(`otp-${index + 1}`).focus();
      }
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && otp[index] === '' && index > 0) {
      document.getElementById(`otp-${index - 1}`).focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const data = e.clipboardData.getData('Text').slice(0, 6);
    if (/^\d+$/.test(data)) {
      const newOtp = Array(6).fill('');
      for (let i = 0; i < data.length; i++) {
        newOtp[i] = data[i];
      }
      setOtp(newOtp);
    }
  };

  // const handleSubmit = async (e) => {
  //   e.preventDefault();
  //   try {
  //    const response = await verifyOtp({ email: email, otp: otp.join('') }).unwrap();
  //     dispatch(setOtpVerified(true));
  //     dispatch(setCredentials({email: email, token: response.accesstoken}));
  //     alert('OTP verified successfully!');
  //     console.log(accesstoken);
  //     navigate('/dummy');
  //   } catch (err) {
  //     console.error(err);
  //   }
  //   alert(`OTP Entered: ${otp.join('')}`);
  //   onClose(); // Close OTP modal on submit
  // };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await verifyOtp({ email, otp: otp.join('') }).unwrap();
      const accesstoken = response.accesstoken; // Extract the token
      dispatch(setCredentials({ email, token: accesstoken })); // Save token
      alert('OTP verified successfully!');
      navigate('/dummy');
    } catch (err) {
      console.error("Error verifying OTP:", err);
      alert('Failed to verify OTP. Please try again.');
    }
    onClose(); // Close OTP modal
  };
  

  return (
    <div className="flex items-center justify-center h-screen z-50 inset-0 fixed bg-black bg-opacity-50">
      <div className="flex gap-4 h-4/5 justify-between items-center w-4/5 border border-gray-300 p-6 rounded-lg" style={{ backgroundColor: '#f1eee3' }}>
        {/* Left side: Harry Potter */}
        <div className="w-1/2 flex items-center justify-center h-full">
          <div className="relative w-2/3 h-2/3">
            <HarryPotter />
          </div>
        </div>

        {/* Right side: OTP Inputs */}
        <div className="w-1/2 h-2/4 mr-8 flex flex-col items-center justify-center bg-gradient-to-b from-gray-100 to-gray-300 rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-semibold text-gray-800 mb-6 text-center tracking-wide font-poppins">
            Enter OTP
          </h1>
          <div className="flex gap-3 mb-8" onPaste={handlePaste}>
            {otp.map((digit, index) => (
              <input
                key={index}
                id={`otp-${index}`}
                type="text"
                maxLength="1"
                value={digit}
                onChange={(e) => handleChange(e, index)}
                onKeyDown={(e) => handleKeyDown(e, index)}
                
                className="w-16 h-16 text-center text-2xl font-semibold border-2 border-gray-400 rounded-lg focus:outline-none focus:ring-4 focus:ring-blue-400 transition duration-200 ease-in-out"
              />
            ))}
          </div>
          <div className="flex justify-center">
            <button
              onClick={handleSubmit}
              className="px-8 py-4 bg-gradient-to-r from-red-500 to-red-700 text-white font-bold text-lg rounded-lg shadow-xl hover:from-red-600 hover:to-red-800 focus:outline-none focus:ring-4 focus:ring-red-500 transition duration-200 ease-in-out"
            >
              Submit OTP
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Otp;

