import React, { useEffect, useState } from "react";
import SeriesCard from "../../uicomponents/SeriesCard";
import { useNavigate, Link } from "react-router-dom";

const genres = [
  "comedy",
  "romance",
  "horror",
  "action",
  "drama",
  "sci-fi",
  "fantasy",
  "thriller"
];


const GenreSection = ({ genre, dataSeries, loadingSeries }) => {
  if (!Array.isArray(dataSeries)) {
    return <div className="text-white">No series data available.</div>;
  }
  const filteredSeries = dataSeries.filter((series) => series.genre === genre);

  return (
    <div className="my-6">
      {loadingSeries === false ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredSeries.length > 0 ? (
            filteredSeries.map((series) => (
              <Link
                to={`/episodes/${series.id}`}
                key={series.id}
                state={{ series: series }}
                className="no-underline"
              >
                <SeriesCard key={series.id} series={series} />
              </Link>
            ))
          ) : (
            <div className="text-gray-400">No series found for {genre}</div>
          )}
        </div>
      ) : (
        <div className="text-gray-400">Loading series...</div>
      )}
    </div>
  );
};

function Readerdashboard() {
  const [randomSeries, setRandomSeries] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const { isLoaded } = useUser();
  const navigate = useNavigate();

  const {
    data: dataSeries = [],
    loading: loadingSeries,
    fn: fnSeries,
  } = useFetch(getSeries);

  useEffect(() => {
    if (isLoaded) fnSeries();
  }, [isLoaded]);

  useEffect(() => {
    if (!loadingSeries && dataSeries.length > 0) {
      const shuffled = dataSeries.sort(() => 0.5 - Math.random());
      setRandomSeries(shuffled.slice(0, 5));
    }
  }, [dataSeries, loadingSeries]);

  const handleBannerClick = (series) => {
    navigate(`/episodes/${series.id}`, { state: { series } });
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const filteredSeries = dataSeries.filter((series) =>
    series.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-gray-900 text-white min-h-screen">
      <div className="relative w-full flex flex-col items-center">
        <div className="relative w-3/4 mt-12">
          <input
            type="text"
            placeholder="Search by series name..."
            className="w-full py-2 px-4 pl-10 rounded-full bg-gray-800 border border-red-500 text-white placeholder-red-300 focus:outline-none focus:ring focus:ring-red-500"
            value={searchQuery}
            onChange={handleSearchChange}
          />
          <i className="fas fa-search absolute top-2.5 left-4 text-red-500"></i>
        </div>
        <div className="w-full overflow-hidden relative h-56 mt-8">
          {randomSeries.length > 0 &&
            randomSeries.map((series, index) => (
              <img
                key={index}
                src={series.banner_img}
                alt={series.title}
                className={`absolute w-full h-full object-cover opacity-0 animate-fade-in-${index}`}
                onClick={() => handleBannerClick(series)}
                style={{ cursor: "pointer" }}
              />
            ))}
        </div>
      </div>

      <div className="p-8">
        {loadingSeries === false && (
          <div>
            <h2 className="text-xl font-bold mb-4">
              {searchQuery ? "Search Results" : "Genres"}
            </h2>
            {searchQuery ? (
              filteredSeries.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {filteredSeries.map((series) => (
                    <Link
                      to={`/episodes/${series.id}`}
                      key={series.id}
                      state={{ series: series }}
                      className="no-underline"
                    >
                      <SeriesCard key={series.id} series={series} />
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-gray-400">No series found matching your search.</div>
              )
            ) : (
              genres.map((genre) => (
                <div key={genre}>
                  <h2 className="text-lg font-semibold mt-8">
                    {genre.charAt(0).toUpperCase() + genre.slice(1)}
                  </h2>
                  <GenreSection
                    genre={genre.charAt(0).toUpperCase() + genre.slice(1)}
                    dataSeries={dataSeries}
                    loadingSeries={loadingSeries}
                  />
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Readerdashboard;
