import React from 'react'

function dummy() {
  return (
    <div>dummy</div>
  )
}

export default dummy