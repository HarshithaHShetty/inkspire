import { SignedIn, SignedOut, UserButton } from "@clerk/clerk-react";
import Landingpage from "./assets/components/Landingpage";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import SignInPage from "./assets/components/SignInPage";
import SignUpPage from "./assets/components/SignUpPage";
import Role from "./assets/components/Role";
import AppLayout from "./assets/Layout/Applayout";
import Readerdashboard from "./assets/Reader/Readerdashboard";
import Creatordashboard from "./assets/Creator/Creatordashboard";
import MyReads from "./assets/Reader/MyReads";
import Favourites from "./assets/Reader/Favourites";
import ProtectedRoute from "./assets/components/ProtectedRoute";
import Navbar from "./assets/uicomponents/Navbar";
import { useUser } from "@clerk/clerk-react";
import Episodes from "./assets/Reader/Episodes";
import Newproject from "./assets/Creator/Newproject";
import Uploadepisode from "./assets/Creator/Uploadepisode";
import Myepisodes from "./assets/Creator/Myepisodes";
import Eps from "./assets/Reader/Eps";
import EditEpisode from "./assets/Creator/EditEpisode";
import Mydrafts from "./assets/Creator/Mydrafts";


export default function App() {
  const { isSignedIn, isLoaded, user } = useUser();
  return (
    <BrowserRouter>
      {/* Routes for non-authenticated users */}
      <Routes>
        <Route
          path="/"
          element={
            <SignedOut>
              <Landingpage />
            </SignedOut>
          }
        />
        <Route
          path="/sign-in/*"
          element={
            <SignedOut>
              <SignInPage />
            </SignedOut>
          }
        />
        <Route
          path="/sign-up/*"
          element={
            <SignedOut>
              <SignUpPage />
            </SignedOut>
          }
        />

        {/* </Routes> */}

        {/* Authenticated routes wrapped in AppLayout */}

        <Route element={<AppLayout />}>
          {isSignedIn && isLoaded && (
            <>
              <Route
                path="/role"
                element={
                  <ProtectedRoute>
                    <Role />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/"
                element={
                  <SignedIn>
                    <ProtectedRoute>
                      <Role />
                    </ProtectedRoute>
                  </SignedIn>
                }
              />
            </>
          )}

          {isLoaded &&
          isSignedIn &&
          user?.unsafeMetadata?.role === "creator" ? (
            <>
              <Route
                path="/"
                element={
                  <ProtectedRoute>
                    <Creatordashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/creatordashboard"
                element={
                  <ProtectedRoute>
                    <Creatordashboard />
                  </ProtectedRoute>
                }
              />

             
              <Route
                path="/new-series"
                element={
                  <ProtectedRoute>
                    <Newproject />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my_episodes/:series_id"
                element={
                  <ProtectedRoute>
                    <Myepisodes />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/uploadep"
                element={
                  <ProtectedRoute>
                    <Uploadepisode />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/episodes/eps/:episode_id"
                element={
                  <ProtectedRoute>
                    <Eps />
                  </ProtectedRoute>
                }
              />
                <Route
    path="/edit-episode/:episodeId"
    element={
      <ProtectedRoute>
        <EditEpisode />
      </ProtectedRoute>
    }
  />
       <Route
    path="/my-drafts"
    element={
      <ProtectedRoute>
        <Mydrafts />
      </ProtectedRoute>
    }
  />
             
              <Route
                path="/readerdashboard"
                element={
                  <ProtectedRoute>
                    <Creatordashboard />
                  </ProtectedRoute>
                }
              />
            </>
          ) : (
            <>
              <Route
                path="/"
                element={
                  <ProtectedRoute>
                    <Navigate to="/role" />;
                  </ProtectedRoute>
                }
              />
              <Route
                path="/readerdashboard"
                element={
                  <ProtectedRoute>
                    <Readerdashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-reads"
                element={
                  <ProtectedRoute>
                    <MyReads />
                  </ProtectedRoute>
                }
              />
                <Route
                path="/favourites"
                element={
                  <ProtectedRoute>
                    <Favourites />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/episodes/:series_id"
                element={
                  <ProtectedRoute>
                    <Episodes />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/episodes/eps/:episode_id"
                element={
                  <ProtectedRoute>
                    <Eps />
                  </ProtectedRoute>
                }
              />

              <Route path="/creatordashboard" element={<Readerdashboard />} />
            </>
          )}
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
