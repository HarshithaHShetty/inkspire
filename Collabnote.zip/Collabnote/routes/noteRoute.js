const express = require("express");
const router = express.Router();
const notecontroller = require("../controller/noteController");
// const verifyRole = require("../middleware/verifyRole");
const getuserdetails=require("../middleware/getuserdetails");
const episodemiddleware=require("../middleware/episodemiddleware")



router.post("/addnote",episodemiddleware,getuserdetails,notecontroller.addCollaboratorNote);
router.get("/getnote/:episode_id",getuserdetails,notecontroller.getNotesForEpisode);
module.exports = router;
