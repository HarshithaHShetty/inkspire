// controllers/collaboratorNoteController.js
const CollaboratorNote = require('../model/note');
const axios = require('axios'); // For making HTTP requests to other services

const addCollaboratorNote = async (req, res) => {
  const { episode_id, imageIndex, userId, collabName,content } = req.body;

  try {
   
    const episode_title = req.data.episode_title; // Get the title

    const note = new CollaboratorNote({
      episode_id,
      episode_title, // Store the title in the note
      imageIndex,
      userId,
      collabName,
      content,
    });
    await note.save();
    res.status(201).json({ message: 'Note added successfully', note });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get notes for a specific episode
const getNotesForEpisode = async (req, res) => {
  const { episode_id } = req.params;
  const collabName=req.body.collabName
  const notesendby=req.user.username

  try {
    const notes = await CollaboratorNote.find({ episode_id ,collabName})

    res.status(200).json({notes,notesendby});
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  addCollaboratorNote,
  getNotesForEpisode,
};
