const allowedOrigins=["http://localhost:3503"]

module.exports = allowedOrigins