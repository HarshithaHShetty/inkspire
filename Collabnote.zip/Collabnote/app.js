const express=require("express");
require('dotenv').config();
const app = express();
const cors = require('cors')
const corsOptions = require('./config/corsOptions')
const connectDB = require('./config/dbConn')
const mongoose = require('mongoose')
const cookieParser=require("cookie-parser");
const verifyJWT = require("./middleware/verifyJWT");
const PORT = process.env.PORT || 3503

connectDB()
app.use(cors(corsOptions))
app.use(express.json())
app.use(cookieParser())


// app.use(verifyJWT)
app.use('/note',require('./routes/noteRoute'))



mongoose.connection.once('open', () => {
    console.log('Connected to MongoDB') 
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`))
})