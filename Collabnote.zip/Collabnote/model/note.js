// models/CollaboratorNote.js
const mongoose = require('mongoose');

const collaboratorNoteSchema = new mongoose.Schema({
  episode_id: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    // No ref to Episode since it's a different microservice
  },
  episode_title: {
    type: String, // Store episode title for easy access
    required: true,
  },
  imageIndex: {
    type: Number,
    required: true,
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'User',
  },
  collabName:{
    type:String
  },
  content: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('CollaboratorNote', collaboratorNoteSchema);
