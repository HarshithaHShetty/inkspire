const axios = require("axios");

const episodemiddleware = async (req, res, next) => {
  const episodeId = req.body.episode_id;

  if (!episodeId) {
    return res.status(400).json({ message: "episode ID are required" });
  }

  try {
    // Make a request to the external microservice to get user details
    console.log(episodeId);

    const response = await axios.get(
      `http://localhost:3501/creator/episode/${episodeId}`,
      {
        headers: {
          Authorization: `Bearer ${req.headers.authorization.split(" ")[1]}`,
        },
      }
    );

    // Check if the response has user data
    if (!response.data._id) {
  
      return res.status(404).json({ message: "no episode found" });
    } else {
      req.data = response.data;
      next(); // Pass control to the next middleware (getCreatorSeries)
    }
  } catch (error) {
    console.error("Error fetching episode details:", error.message);
    return res
      .status(500)
      .json({
        error: "Failed to fetch episode details from the other service",
      });
  }
};

module.exports = episodemiddleware;
