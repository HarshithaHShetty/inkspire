const verifyRole = (requiredRole) => {
    return (req, res, next) => {
        // Check if the user role matches the required role
        if (req.user_role !== requiredRole) {
            console.log(req.user_role,requiredRole)
            return res.status(403).json({ message: 'Access denied: insufficient permissions!' });
        }
        console.log(req.user_role,requiredRole,"outside if")
        // If the role matches, proceed to the next middleware or route handler
        next();
    };
};

module.exports = verifyRole;
