const axios = require("axios");

const getuserdetails = async (req, res, next) => {
  const userid = req.body.userId; // Assuming the user ID is passed in the request body
  const collabName=req.body.collabName

  if (!userid || !collabName) {
    return res.status(400).json({ message: "User ID and collabname are required" });
  }

  try {
    // Make a request to the external microservice to get user details

    const response1 = await axios.get(`http://localhost:3500/users/${userid}`, {
      headers: {
        Authorization: `Bearer ${req.headers.authorization.split(" ")[1]}`,
      },
    });

    const response2 = await axios.get(`http://localhost:3500/users/username/${collabName}`, {
      headers: {
        Authorization: `Bearer ${req.headers.authorization.split(" ")[1]}`,
      },
    });
console.log(response2)
    // Check if the response has user data
    if (!response1.data.username || !response2.data.username ) {
      return res.status(404).json({ message: "No user found" });
    } else {
      req.user = response1.data;
      next(); // Pass control to the next middleware (getCreatorSeries)
    }
  } catch (error) {
    console.error("Error fetching user details:", error.message);
    return res
      .status(500)
      .json({ error: "Failed to fetch user details from the other service" });
  }
};

module.exports = getuserdetails;
