const express = require("express");
const router = express.Router();
const usercontroller = require("../controller/usercontroller");
const verifyJWT = require("../middleware/verifyJwt");
const multer = require("multer");
const { uploadImage } = require("../controller/usercontroller");

const storage = multer.memoryStorage();
const upload = multer({ storage });

router.use(verifyJWT)
router.route("/").get(usercontroller.getAllUsers);
router.route("/:userid").get(usercontroller.getUserById);
router.route('/username/:username').get(usercontroller.getUserByName) ;

router.route("/updateprofile/:userid").patch(usercontroller.updateProfile);

router.post("/upload/:userid", upload.single("file"), uploadImage);

module.exports = router;
