const express = require("express");
const router = express.Router();
const authcontroller = require("../controller/authcontroller");

router.route("/").post(authcontroller.Register);
router.route("/login").post(authcontroller.Login);
router.route("/verifyotp").post(authcontroller.VerifyOtp);
router.route("/logout").post(authcontroller.Logout);
router.route("/refreshtoken").post(authcontroller.Refreshtoken);

router.route("/forgotpassword").patch(authcontroller.forgotPassword);
router.route("/resetpassword/:token").patch(authcontroller.resetPassword);

module.exports = router;
