const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      required: true,
    },
    secret: { type: String },
    penname: {
      type: String,
    },
    profileimg: {
      type: String,
    },

    resetPasswordToken: {
      type: String, // Token used for resetting the password
    },
    resetPasswordExpires: {
      type: Date, // Expiration time for the reset token
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("User", userSchema);
