const user = require("../model/users");
require("mongoose");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const path = require("path");
const supabase = require("../config/supabase");
const dotenv = require("dotenv");

//getalluser
//route/ /users/
//private
const getAllUsers = async (req, res) => {
  const users = await user.find().exec();

  if (users) {
    return res.status(200).json(users);
  } else {
    return res.status(400).json("no users found");
  }
};

//getuserbyid
//route/ users/:userid
//private
const getUserById = async (req, res) => {
  const id = req.params.userid;
  console.log(id);
  const users = await user.findById(id).exec();
  console.log(users);

  if (users) {
    return res.status(200).json(users);
  } else {
    return res.status(400).json("no user found");
  }
};

//getuserbyusername
//route/ users/:username
//private
const getUserByName = async (req, res) => {
  const { username } = req.params;
  console.log(username)
  try {
    const User = await user.findOne({ username }).exec();
    if (User) {
      return res.status(200).json(User);
    } else {
      return res.status(404).json({ message: "No user found" });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
};


//  Update a user
// /users/upadateprofile/:userid
//  Private
const updateProfile = async (req, res) => {
  const { username, role, password, penname } = req.body;
  const id = req.params.userid;
  // Confirm data
  if (!id) {
    return res.status(400).json({ message: "Id is required" });
  }

  // Does the user exist to update?
  const User = await user.findById(id).exec();

  if (!User) {
    return res.status(400).json({ message: "User not found" });
  }
  if (!id || !username || !role) {
    return res
      .status(400)
      .json({ message: "All fields except password are required" });
  }

  // Check for duplicate
  const duplicate = await user
    .findOne({ username })
    .collation({ locale: "en", strength: 2 })
    .lean()
    .exec(); // Case-insensitive

  // Allow updates to the original user
  if (duplicate && duplicate?._id.toString() !== id) {
    return res.status(409).json({ message: "Duplicate username" });
  }

  User.username = username;
  User.role = role;
  if (penname) {
    User.penname = penname;
  }
  if (password) {
    // Hash password
    User.password = await bcrypt.hash(password, 10); // salt rounds
  }

  const updatedUser = await User.save();

  res.json({ message: `${updatedUser.username} updated` });
};

// Upload image to Supabase Storage
///route upload/:userid
//private
const uploadImage = async (req, res) => {
  const file = req.file;
  const id = req.params.userid;
  console.log(id);
  if (!id) {
    return res.status(400).json({ message: "ID is required" });
  }

  if (!file) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  // Does the user exist to update?
  const User = await user.findById(id).exec();
  console.log(User);
  if (!User) {
    return res.status(400).json({ message: "User not found" });
  }
  try {
    // Generate a unique filename using random bytes and original file extension
    const fileName =
      crypto.randomBytes(16).toString("hex") + path.extname(file.originalname);

    // Upload the image to Supabase storage bucket
    const { data, error } = await supabase.storage
      .from("profileimg") // Replace with your actual bucket name in Supabase
      .upload(fileName, file.buffer, {
        contentType: file.mimetype,
      });

    if (error) {
      console.error("Supabase storage error:", error);
      return res
        .status(500)
        .json({ error: "Error uploading file to Supabase" });
    }

    // Generate the public URL using Supabase API
    const { data: publicData, error: publicError } = supabase.storage
      .from("profileimg")
      .getPublicUrl(fileName);

    if (publicError) {
      console.error("Error getting public URL:", publicError);
      return res.status(500).json({ error: "Error generating public URL" });
    }

    const publicURL = publicData.publicUrl;
    console.log("Public URL:", publicURL);

    //save publicURl to db
    User.profileimg = publicURL;

    const updatedUser = await User.save();

    // Return the public URL in the response
    return res.status(200).json({
      message: "File uploaded successfully",
      fileUrl: publicURL,
    });
  } catch (err) {
    console.error("Error:", err);
    return res.status(500).json({ error: "Server error" });
  }
};

module.exports = {
  getAllUsers,
  getUserById,
  getUserByName,
  updateProfile,
  uploadImage,
};
