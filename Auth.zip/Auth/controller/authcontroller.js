const User = require("../model/users");
require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const transporter = require("../config/emailconfig");
const speakeasy = require("speakeasy");
const dotenv = require("dotenv");
const crypto = require("crypto");
const rateLimit = require("express-rate-limit");
const { check, validationResult } = require("express-validator");

// Rate limiter for forgot password
const forgotPasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit to 5 requests per window per IP
  message: "Too many password reset attempts. Please try again later.",
});

// Registration logic
//route /auth/
//public
const Register = async (req, res) => {
  const { username, password, email, role } = req.body;

  if (!username || !email || !password || !role) {
    return res.status(400).json("All fields are required");
  }

  const duplicate = await User.findOne({ username }).exec();
  if (duplicate) {
    return res.status(409).json("Username already exists");
  }

  const duplicateemail = await User.findOne({ email }).exec();
  if (duplicateemail) {
    return res.status(409).json("Email already exists");
  }

  const hashpassword = await bcrypt.hash(password, 10);
  const secret = speakeasy.generateSecret({ length: 20 }).base32; // OTP secret

  const userObj = { username, password: hashpassword, email, role, secret };

  try {
    const newUser = await User.create(userObj);
    return res.status(200).json("Registration successful");
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// Login and send OTP
//public
//route /auth/login
const Login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json("Email and password are required");
  }

  const userlogin = await User.findOne({ email }).exec();


  if (!userlogin) {
    return res.status(409).json("User does not exist");
  }

  const match = await bcrypt.compare(password, userlogin.password);
  if (!match) {
    return res.status(401).json("Unauthorized");
  }

  // Generate OTP
  const otp = speakeasy.totp({
    secret: userlogin.secret,
    encoding: "base32",
  });

  try {
    // Send OTP via email
    await transporter.sendMail({
      from: process.env.EMAIL,
      to: userlogin.email,
      subject: "Your OTP Code",
      text: `Your OTP code is ${otp}`,
    });

    return res.status(200).json({
      message: "OTP sent",
      user: { email: req.body.email } // Example user data
    });
  } catch (err) {
    console.error("Error sending OTP:", err);
    return res.status(500).json("Failed to send OTP");
  }
};

// Verify OTP and issue tokens
//route /auth/verifyotp
//public
const VerifyOtp = async (req, res) => {
  const { email, otp } = req.body;

  const userlogin = await User.findOne({ email }).exec();

  console.log(userlogin)
  if (!userlogin) {
    return res.status(404).json("User not found");
  }
console.log(userlogin)
  const verified =
  speakeasy.totp.verify({
    secret: userlogin.secret,
    encoding: "base32",
    token: otp,
    window: 1,
  });

  if (verified) {
    const accesstoken = jwt.sign(
      { userinfo: { username: userlogin.username, role: userlogin.role } },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: "60m" }
    );

    const refreshtoken = jwt.sign(
      { username: userlogin.username },
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: "1d" }
    );

    res.cookie("jwt", refreshtoken, {
      httpOnly: true,
      secure: true,
      sameSite: "None",
      maxAge: 24 * 60 * 60 * 1000,
    });
    console.log("Received OTP:", req.body.otp);
    console.log("Looking up user:", req.body.email || req.body.token);

    return res.status(200).json({ accesstoken });
  } else {
    return res.status(401).json("Invalid OTP");
  }
};

//refreshtoken
//route /auth/refreshtoken
//public
const Refreshtoken = (req, res) => {
  const cookies = req.cookies;

  if (!cookies?.jwt) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const refreshtoken = cookies.jwt;
  jwt.verify(
    refreshtoken,
    process.env.REFRESH_TOKEN_SECRET,
    async (err, decoded) => {
      if (err) {
        return res.status(403).json({ message: "Forbidden" });
      }
      const founduser = await User.findOne({
        username: decoded.username,
      }).exec();
      if (!founduser) {
        return res.status(404).json("User not found");
      }
      const accesstoken = jwt.sign(
        { userinfo: { username: founduser.username, role: founduser.role } },
        process.env.ACCESS_TOKEN_SECRET,
        { expiresIn: "60m" }
      );
   
      res.json({ accesstoken });
    }
  );
};

//logout
//public
//route /auth/logout
const Logout = (req, res) => {
  const cookies = req.cookies;

  if (!cookies?.jwt) {
    return res.sendStatus(204);
  }

  res.clearCookie("jwt", {
    httpOnly: true,
    secure: true,
    sameSite: "None",
  });

  res.json({ message: "cookies cleared" });
};

//forgotpassword
//public
//route /forgotpassword

// Forgot password with rate limiting
const forgotPassword =
  (forgotPasswordLimiter,
  [check("email").isEmail().withMessage("Please enter a valid email")],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email } = req.body;

    const user = await User.findOne({ email }).exec();
    if (!user) {
      return res.status(404).json("User with this email does not exist");
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString("hex");
    const resetTokenHash = crypto
      .createHash("sha256")
      .update(resetToken)
      .digest("hex");

    // Set token expiration (1 hour)
    user.resetPasswordToken = resetTokenHash;
    user.resetPasswordExpires = Date.now() + 3600000;
    await user.save();

    const resetLink = `${process.env.CLIENT_URL}/resetpassword/${resetToken}`;

    try {
      // Send reset link via email
      await transporter.sendMail({
        from: process.env.EMAIL,
        to: user.email,
        subject: "Password Reset Request",
        html: `
          <p>You requested a password reset</p>
          <p>Click this <a href="${resetLink}">link</a> to reset your password. The link is valid for 1 hour.</p>
        `,
      });

      return res.status(200).json({ resetLink });
    } catch (error) {
      console.error("Error sending email:", error);
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;
      await user.save();
      return res.status(500).json("Failed to send password reset link");
    }
  });

// Reset password
//route /resetpassword/:token
const resetPassword = async (req, res) => {
  const { token } = req.params;
  const { newPassword } = req.body;
  console.log(token);
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json("Password must be at least 6 characters long");
  }

  const resetTokenHash = crypto
    .createHash("sha256")
    .update(token)
    .digest("hex");

  const user = await User.findOne({
    resetPasswordToken: resetTokenHash,
    resetPasswordExpires: { $gt: Date.now() },
  }).exec();

  if (!user) {
    return res.status(400).json("Invalid or expired reset token");
  }

  const hashedPassword = await bcrypt.hash(newPassword, 12);
  user.password = hashedPassword;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpires = undefined;

  await user.save();

  return res.status(200).json("Password has been reset successfully");
};

module.exports = {
  Register,
  Login,
  VerifyOtp,
  Logout,
  Refreshtoken,
  forgotPassword,
  resetPassword,
};
