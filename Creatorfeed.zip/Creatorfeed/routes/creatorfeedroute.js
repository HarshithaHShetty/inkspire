const express = require("express");
const router = express.Router();
const creatorfeedcontroller = require("../controller/creatorfeedController");
const verifyRole = require("../middleware/verifyRole");
const verifyJWT = require("../middleware/verifyJWT");
const multer = require("multer");
const upload = multer();


router.post("/newpost",upload.single('content_img'), creatorfeedcontroller.createpost);

// Route for getting all posts
router.get("/getposts", creatorfeedcontroller.getPosts);

// Route for getting a post by ID
router.get("/posts/:postId", creatorfeedcontroller.getPostById);

// Route for updating a post by ID
router.put("/updatepost/:postId", upload.single("content_img"), creatorfeedcontroller.updatePost);

// Route for deleting a post by ID
router.delete("/deletepost/:postId", creatorfeedcontroller.deletePost);

// Route for getting all posts by creator ID
router.get("/postsbycreatorid/:creator_id", creatorfeedcontroller.getPostsByCreatorId);

module.exports = router;
