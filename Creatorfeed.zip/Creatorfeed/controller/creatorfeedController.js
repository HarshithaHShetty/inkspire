const supabase = require("../config/supabase");
const Creatorfeed = require("../model/creatorfeed");
const mongoose = require("mongoose");
const crypto = require("crypto"); // Ensure crypto is imported
const path = require("path"); // Ensure path is imported
const { ObjectId } = require('mongodb');
const createpost = async (req, res) => {
  try {
    const { creator_id, content_text } = req.body;
    const content_img = req.file; // Assuming multer setup as `upload.single("content_img")`

    console.log("creator_id:", creator_id);  
    console.log("content_text:", content_text);
    console.log("content_img:", content_img);

    // Check for required fields
    if (!creator_id || (!content_text && !content_img)) {
      return res.status(400).json({ error: "creator_id and at least one content (text or image) are required." });
    }

    let content_img_url = null; // Default to null in case no image upload is provided

    // If content_img exists, handle image upload
    if (content_img) {
      try {
        // Generate a unique filename and upload the image
        const file_name = crypto.randomBytes(16).toString("hex") + path.extname(content_img.originalname);

        const { data: postData, error: postError } = await supabase.storage
          .from("Postimgs")
          .upload(file_name, content_img.buffer, { contentType: content_img.mimetype });

        if (postError) {
          console.error("Supabase storage error (content_img):", postError);
          return res.status(500).json({ error: "Error uploading content_img to Supabase" });
        }

        // Get the public URL for the uploaded image
        const { data: content_imgPublicData, error: content_imgPublicError } = 
          supabase.storage.from("Postimgs").getPublicUrl(file_name);

        if (content_imgPublicError) {
          console.error("Error getting public URL (content_img):", content_imgPublicError);
          return res.status(500).json({ error: "Error generating public URL for content_img" });
        }

        content_img_url = content_imgPublicData.publicUrl;
      } catch (uploadErr) {
        console.error("Error during image upload:", uploadErr);
        return res.status(500).json({ error: "Failed to upload image to storage." });
      }
    }

    // Create the new post in MongoDB
    const newPost = await Creatorfeed.create({
      creator_id,
      content_text,
      content_img: content_img_url
    });

    res.status(200).json({ message: "Post uploaded successfully", post: newPost });
  } catch (err) {
    console.error("Error creating post:", err);
    res.status(500).json({ error: "Error creating post" });
  }
};


const getPosts = async (req, res) => {
  try {
    const posts = await Creatorfeed.find(); // Fetch all posts
    res.status(200).json(posts); // Return posts
  } catch (err) {
    console.error("Error fetching posts:", err);
    res.status(500).json({ error: "Error fetching posts" });
  }
};


const getPostById = async (req, res) => {
  const { postId } = req.params; // Assuming you're sending the post ID as a URL parameter

  if (!postId) {
    return res.status(400).json({ error: "Post ID is required" });
  }

  try {
    const post = await Creatorfeed.findById(postId); // Find the post by ID

    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    res.status(200).json(post); // Return the post
  } catch (err) {
    console.error("Error fetching post:", err);
    res.status(500).json({ error: "Error fetching post" });
  }
};

const getPostsByCreatorId = async (req, res) => {
  const { creator_id } = req.params; // Assuming you're sending the creator ID as a URL parameter

  if (!creator_id) {
    return res.status(400).json({ error: "Creator ID is required" });
  }

  try {
    const posts = await Creatorfeed.find({ creator_id }); // Fetch posts by creator_id

    if (posts.length === 0) {
      return res.status(404).json({ message: "No posts found for this creator." });
    }

    res.status(200).json(posts); // Return the posts
  } catch (err) {
    console.error("Error fetching posts by creator ID:", err);
    res.status(500).json({ error: "Error fetching posts" });
  }
};


const updatePost = async (req, res) => {
  const { postId } = req.params; // Get the post ID from URL parameters
  const { content_text, creator_id } = req.body; // Get the new content and creator ID from the request body
  const content_img = req.file; // Handle optional image upload

  if (!postId) {
    return res.status(400).json({ error: "Post ID is required" });
  }

  try {
    const post = await Creatorfeed.findById(postId); // Find the post by ID

    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    // Convert creator_id from string to ObjectId for comparison
    const creatorIdObject = new ObjectId(creator_id); // Use 'new' to create an instance

    // Check if the creator_id from the request matches the post's creator_id
    if (!post.creator_id.equals(creatorIdObject)) {
      console.log(post.creator_id, creatorIdObject);
      return res.status(403).json({ error: "You are not authorized to update this post" });
    }

    let content_img_url = post.content_img; // Default to existing image URL if no new image is provided

    // If a new content_img exists, handle image upload
    if (content_img) {
      // Handle image upload as before
      const file_name = crypto.randomBytes(16).toString("hex") + path.extname(content_img.originalname);

      const { data: postData, error: postError } = await supabase.storage
        .from("Postimgs")
        .upload(file_name, content_img.buffer, { contentType: content_img.mimetype });

      if (postError) {
        console.error("Supabase storage error (content_img):", postError);
        return res.status(500).json({ error: "Error uploading content_img to Supabase" });
      }

      const { data: content_imgPublicData, error: content_imgPublicError } = 
        await supabase.storage.from("Postimgs").getPublicUrl(file_name);

      if (content_imgPublicError) {
        console.error("Error getting public URL (content_img):", content_imgPublicError);
        return res.status(500).json({ error: "Error generating public URL for content_img" });
      }

      content_img_url = content_imgPublicData.publicUrl; // Update with new image URL
    }

    // Update the post in MongoDB
    post.content_text = content_text || post.content_text; // Only update if new content is provided
    post.content_img = content_img_url; // Update the image URL if a new one is provided

    await post.save(); // Save changes to the database

    res.status(200).json({ message: "Post updated successfully", post }); // Return updated post
  } catch (err) {
    console.error("Error updating post:", err);
    res.status(500).json({ error: "Error updating post" });
  }
};

const deletePost = async (req, res) => {
  const { postId } = req.params; // Assuming you're sending the post ID as a URL parameter

  if (!postId) {
    return res.status(400).json({ error: "Post ID is required" });
  }

  try {
    const post = await Creatorfeed.findById(postId); // Find the post in MongoDB

    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    // Check if content_img is not null and is an array with at least one element
    if (Array.isArray(post.content_img) && post.content_img.length > 0) {
      console.log(post.content_img);

      // Extract the first image URL from the array
      const content_img_url = post.content_img[0]; // Get the image URL from the post

      // Extract the file name from the public URL
      const fileName = path.basename(content_img_url); // This assumes the URL ends with the file name

      // Delete the image from Supabase storage
      const { error: deleteImageError } = await supabase.storage
        .from("Postimgs")
        .remove([fileName]); // Make sure to pass the fileName as an array

      if (deleteImageError) {
        console.error("Supabase storage error (delete image):", deleteImageError);
        return res.status(500).json({ error: "Error deleting image from Supabase" });
      }
    } else {
      console.warn("No image URL to delete for this post.");
    }

    // Now delete the post from MongoDB
    await Creatorfeed.findByIdAndDelete(postId);

    res.status(200).json({ message: "Post deleted successfully" });
  } catch (err) {
    console.error("Error deleting post:", err);
    res.status(500).json({ error: "Error deleting post" });
  }
};



module.exports = { createpost, getPosts, getPostById, updatePost, deletePost,getPostsByCreatorId };

