const allowedOrigins=["http://localhost:3504"]

module.exports = allowedOrigins