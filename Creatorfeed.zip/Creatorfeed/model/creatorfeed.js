const mongoose = require('mongoose')


const creatorfeedSchema = new mongoose.Schema({
    creator_id: {
        type: mongoose.Schema.Types.ObjectId, // Just storing the user ID
        required: true,     
    },
    content_text: {
        type:String  
    }, 
    content_img: {
        type:[String]
    }, 
    }, {
      timestamps: true,
    
})


module.exports = mongoose.model('Creatorfeed', creatorfeedSchema)