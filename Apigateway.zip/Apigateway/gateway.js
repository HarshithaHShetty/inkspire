const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
 
const app = express();
const port = 3000; // Port for the API Gateway




// Microservices endpoints
const authServiceUrl = 'http://localhost:3500'; // Auth and User microservices
const creatorServiceUrl = 'http://localhost:3501'; // Creator microservices
const feedbackServiceUrl = 'http://localhost:3502';
const collabnoteServiceUrl = 'http://localhost:3503';
const creatorfeedServiceUrl = 'http://localhost:3504';

 
// Proxy requests to the authentication service
app.use(
  '/auth',
  createProxyMiddleware({
    target: `${authServiceUrl}/auth`,
    changeOrigin: true,
    pathRewrite: { '^/auth': '' }, // Remove /auth prefix before forwarding
  })
);
 
// Proxy requests to the user service
app.use(
  '/users',
  createProxyMiddleware({
    target: `${authServiceUrl}/users`,
    changeOrigin: true,
    pathRewrite: { '^/users': '' }, // Remove /users prefix before forwarding
  })
);
 
// Proxy requests to the series service
app.use(
  '/creator/series',
  createProxyMiddleware({
    target: `${creatorServiceUrl}/creator/series`,
    changeOrigin: true,
    pathRewrite: { '^/creator/series': '' }, // Remove /creator/series prefix before forwarding
  })
);
 
// Proxy requests to the episode service
app.use(
  '/creator/episode',
  createProxyMiddleware({
    target: `${creatorServiceUrl}/creator/episode`,
    changeOrigin: true,
    pathRewrite: { '^/creator/episode': '' }, // Remove /creator/episode prefix before forwarding
  })
);

app.use(
  '/feedback',
  createProxyMiddleware({
    target: `${feedbackServiceUrl}/feedback`,
    changeOrigin: true,
    pathRewrite: { '^/feedback': '' }, // Remove /auth prefix before forwarding
  })
);
app.use(
  '/comment',
  createProxyMiddleware({
    target: `${feedbackServiceUrl}/comment`,
    changeOrigin: true,
    pathRewrite: { '^/comment': '' }, // Remove /auth prefix before forwarding
  })
);
 

app.use(
  '/note',
  createProxyMiddleware({
    target: `${collabnoteServiceUrl}/note`,
    changeOrigin: true,
    pathRewrite: { '^/note': '' }, // Remove /auth prefix before forwarding
  })
);


app.use(
  '/creatorfeed',
  createProxyMiddleware({
    target: `${creatorfeedServiceUrl}/creatorfeed`,
    changeOrigin: true,
    pathRewrite: { '^/creatorfeed': '' }, // Remove /auth prefix before forwarding
  })
);
// Start the API Gateway server
app.listen(port, () => {
  console.log(`API Gateway running at http://localhost:${port}`);
});
 